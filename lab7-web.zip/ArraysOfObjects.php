<!DOCTYPE html>
<html>
<head>
<title>ArraysOfObjects</title>
<link rel="stylesheet" type="text/css" href="styleSheet.css" />
</head>

<body>

<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>

<div class="content">

<?php
 class Employee{
       protected $employeeId;
       protected $firstName;
       protected $lastName;
	   
	   
       function __construct($employeeId, $firstName, $lastName){
		   $this -> employeeId = $employeeId;
		   $this -> firstName = $firstName;
		   $this ->lastName = $lastName;
       }
       public function getEmployeeId(){
       }
       public function setEmployeeId($employeeId){
       }
       public function getFirstName(){
       }
       public function setFirstName($firstName){
       }
       public function getLastName(){
       }
       public function setLastName($lastName){
       }
	   
	   public function display() {
		return "EmloyeeId: " . $this->employeeId . ",  Name: " . $this->firstName . ", Supervisor: " . $this->lastName   ;
	}

}

class Supervisor extends Employee {
	private $employees;
	
	function __construct($employeeId,$firstName, $lastName, $employees) {
		parent::__construct ($employeeId,$firstName, $lastName);
		$this->employees = $employees;
	}
	public function getEmployees(){
    }
    public function setEmployees($employees){
    }
	
	
}

echo "<br/>";
echo "<br/>";


$Supervisor = new Employee (1,"Chris Rogers", "Adam Phillip");
echo $Supervisor->display ();
echo "<br/>";
$Supervisor= new Employee (2 ,"Matt prior", "Adam Phillip");
echo $Supervisor->display ();
echo "<br/>";
$Supervisor = new Employee (3,"Cindy Burnskill", "Adam Phillip");
echo $Supervisor->display ();
echo "<br/>";
$Supervisor = new Employee (4,"Elizabeth Ford", "Nicolas Jones");
echo $Supervisor->display ();
echo "<br/>";
$Supervisor = new Employee (5,"Doug May", "Nicolas Jones");
echo $Supervisor->display ();
echo "<br/>";
$Supervisor = new Employee (6,"John Hopkins", "Nicolas Jones");
echo $Supervisor->display ();







?>

</div>

<?php include "Footer.php"; ?>

</body>

</html>