<?php
echo "<div id=\"menu\">";
echo "<br />";
echo "<br />";

echo '<a href="Arrays.php">Arrays</a>';
echo "<br />";
echo "<br />";
echo '<a href="ArraysOfObjects.php">ArraysOfObjects</a>';
echo "<br />";
echo "<br />";
echo "</div>";
?> 