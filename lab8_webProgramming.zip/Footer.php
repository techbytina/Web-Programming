<?php

echo "<div id=\"footer\">";
echo "<br/>";
echo "Student Number: 040885113<br/>";

echo "First Name: Maryam <br/>";
echo "Last Name: Afshar<br/>";

echo "Email Address:afsh0004@algonquinlive.com<br/>";

echo "</div>";
?>
