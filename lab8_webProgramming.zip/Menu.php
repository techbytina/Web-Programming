<?php
echo "<div id=\"menu\">";
echo "<br />";
echo "<br />";
echo '<a href="Input.php">Input</a>';
echo "<br />";
echo "<br />";
echo '<a href="Session1.php">Session 1</a>';
echo "<br />";
echo "<br />";
echo '<a href="Session2.php">Session 2</a>';
echo "<br />";
echo "<br />";
echo "</div>";
?> 