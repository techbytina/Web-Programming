<!DOCTYPE>
<html>
<head>
<title>Session2</title>
<link rel="StyleSheet" type="text/css" href="StyleSheet.css" />
</head>

<body>
		
		<?php include "Header.php"; ?>
		<?php include "Menu.php"; ?>

		<div class="content">
		
		<?php
		
		session_start ();
		
		
	    $_SESSION ["First"] = $_POST ["FirstName"];
		$_SESSION ["Last"] = $_POST ["LastName"];
		$_SESSION ["PhoneNum"] = $_POST ["TelephoneNumber"];
		$_SESSION ["Email"] = $_POST ["email"];
		$_SESSION ["birth"] = $_POST ["birthday"];
		$_SESSION ["Category"] = $_POST ["profession"];
		$_SESSION ["apps"] = $_POST ["selectSport"];
		
		
		
		if (isset ( $_SESSION ["First"] )) {
			echo "<b>First Name: </b>" . $_SESSION ['First'];
			echo "<br />";
		} else
			echo "First name : <br />";
		
		if (isset ( $_SESSION ["Last"] )) {
			echo "<b>Last Name: </b>" . $_SESSION ['Last'];
			echo "<br />";
		} else
			echo "Last name : <br />";
		
		if (isset ( $_SESSION ["TelephoneNumber"] )) {
			echo "<b>TelephoneNumber: </b>" . $_SESSION ['TelephoneNumber'];
			echo "<br />";
		} else
			echo "TelephoneNumber is: <br />";
		
		if (isset ( $_SESSION ["email"] )) {
			echo "<b>Email: </b>" . $_SESSION ['email'];
			echo "<br />";
		} else
			echo "Email is: <br />";
			
		if (isset ( $_POST ["profession"] )) {
			echo "<b>profession: </b>" . $_SESSION ['Category'];
			echo "<br />";
		} 
			

		if (isset ( $_POST ["selectSport"] )) {
		echo "<b>Favourit Sport: </b>" . $_SESSION ['apps'];
		echo "<br />";
		 
		} 
		
		?>
		 </div>
		
		 <?php include "Footer.php"; ?>  
	</body>
</html>