<!DOCTYPE>
<html>
<head>
<title>Input.php</title>
<link rel="StyleSheet" type="text/css" href="StyleSheet.css" />
</head>

<body>
    <?php include "Header.php"; ?>
    <?php include "Menu.php"; ?>
           
    <div class="content">
        <div class="left">

		<form method="post">

			<table frame="border">
				<tr>
					<td><b>First Name:</b></td>
					<td><input type="text" name="FirstName"></td>
				</tr>
				<tr>
					<td><b>Last Name:</td></b>
					<td><input type="text" name="LastName"></td>
				</tr>
				<tr>
					<td><b>Telephone Number:</td></b>
					<td><input type="number" name="TelephoneNumber"></td>
				</tr>
				
				
				
				<tr>
					<td><b>Email:</b></td>
					<td><input type="email" name="email"></td>
				</tr>
				
				<tr>
					<b><td><b>Birth Day: </b></td></b>
					<td><input type="date" name="birthday"></td>
				</tr>
				<tr>
				
				</table>
				</br>
				</br>
				</br>
				
				<table frame="border" >
					<td><h3>profrssion:</td></h3>
					
					<td><input type="radio" name="radio"value="Student">Student<br /> 
						<input type="radio" name="radio" value="Doctor">Doctor<br />
						<input type="radio" name="radio" value="Farmer">Farmer<br />
						<input type="radio" name="radio" value="Engineer">Engineer<br />
						
						
					</td>
				</tr>
				</table>
				</br>
				</br>
				<table frame="border">
				<tr>
					<td><h3><b>Favorite Sports:</b></h3></td>
					<td><select name="selectSport">
							<option value="Nothing Selected">Please select...</option>
							<option value="Hockey">Hockey</option>
							<option value="Football">Football</option>
							<option value="Carling">Carling</option>
							<option value="Tennis">Tennis</option>
					</select></td>
				</tr>
				</table>
				</br>
				</br>
				<table>
				<tr>
					<td><input type="submit" value="Submit"></td>
					<td><input type ="reset" value="Reset"></td>
				</tr>
				</table>
			
		</form>
		</div>
		<?php
		
		if (isset ( $_POST ["FirstName"] ))
			$firstName = $_POST ["FirstName"];
		else
			$firstName = "";
		
		if (isset ( $_POST ["LastName"] ))
			$lastName = $_POST ["LastName"];
		else
			$lastName = "";
		
		if (isset ( $_POST ["TelephoneNumber"] ))
			$telephoneNumber = $_POST ["TelephoneNumber"];
		else
			$telephoneNumber = "";
		
		if (isset ( $_POST ["email"] ))
			$email = $_POST ["email"];
		else
			$email = "";
		
		if (isset ( $_POST ["birthday"] ))
			$birthday = $_POST ["birthday"];
		else
			$birthday = "";
		
		if (isset ( $_POST ["radio"] ))
			$radio = $_POST ["radio"];
		else
			$radio = "";
		
		if (isset ( $_POST ["selectSport"] ))
			$sport = $_POST ["selectSport"];
		else
			$sport = "";
		?>
		
		<div class="right">
		<?php 
		echo "<table>";
		echo "<tr><td>First Name: " . $firstName . "</td></tr><br/>";
		echo "<tr><td>Last Name: " . $lastName . "</td></tr><br/>";
		echo "<tr><td>Telephone Number: " . $telephoneNumber . "</td></tr><br/>";
		echo "<tr><td>Email: " . $email . "</td></tr><br/>";
		echo "<tr><td> Birth Day: " . $birthday . "</td></tr><br/>";
		echo "<tr><td>Profession: " . $radio . "</td></tr><br/>";
		echo "<tr><td>Favorit Sport: " . $sport . "</td></tr><br/>";
		echo "</table>";
		?>
		
		</div>
		
	</div>
	

	<?php include "Footer.php"; ?>

</body>
</html>