<!DOCTYPE>
<html>
<head>
<title>Session1</title>
<link rel="Stylesheet" type="text/css" href="StyleSheet.css" />
</head>

<body>
<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>
        
	<div class="content">
	
	<?php
	
	session_start ();
	
	if (isset ( $_POST ["submit"] )) {
		
		$_SESSION ["First"] = $_POST ["FirstName"];
		$_SESSION ["Last"] = $_POST ["LastName"];
		$_SESSION ["PhoneNum"] = $_POST ["TelephoneNumber"];
		$_SESSION ["Email"] = $_POST ["email"];
		$_SESSION ["birth"] = $_POST ["birthday"];
		$_SESSION ["Category"] = $_POST ["profession"];
		$_SESSION ["apps"] = $_POST ["selectSport"];
		
		
		header ( "Location: Session2.php" );
		exit ();
	}
	
	?>
		<form method="post" action="Session2.php">
		<table frame="border">
				<tr>
					<td>First Name:</td>
					<td><input type="text" name="FirstName"></td>
				</tr>
				<tr>
					<td>Last Name:</td>
					<td><input type="text" name="LastName"></td>
				</tr>
				<tr>
					<td>Telephone Number:</td>
					<td><input type="number" name="TelephoneNumber"></td>
				</tr>
				
				
				
				<tr>
					<td>Email:</td>
					<td><input type="email" name="email"></td>
				</tr>
				
				<tr>
					<td>Birth Day</td>
					<td><input type="date" name="birthday"></td>
				</tr>
				<tr>
				
				</table>
				</br>
				</br>
				</br>
				
				<table frame="border" >
					<td>profrssion:</td>
					
					<td><input type="radio" name="profession"value="Student">Student<br /> 
						<input type="radio" name="profession" value="Doctor">Doctor<br />
						<input type="radio" name="profession" value="Farmer">Farmer<br />
						<input type="radio" name="profession" value="Engineer">Engineer<br />
						
						
					</td>
				</tr>
				</table>
				</br>
				</br>
				<table frame="border">
				<tr>
					<td>Favorite Sports:</td>
					<td><select name="selectSport">
							<option value="Nothing Selected">Please select...</option>
							<option value="Hockey">Hockey</option>
							<option value="Football">Football</option>
							<option value="Carling">Carling</option>
							<option value="Tennis">Tennis</option>
					</select></td>
				</tr>
				</table>
				</br>
				</br>
				<table>
				<tr>
					<td><input type="submit" value="Submit"></td>
					<td><input type ="reset" value="Reset"></td>
				</tr>
				</table>
		</form>

	</div>
		 <?php include "Footer.php"; ?> 
	</body>
</html>