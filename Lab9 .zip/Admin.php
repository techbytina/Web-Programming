<!DOCTYPE html>

<?php
session_start ();
function test_input($value) {
	$value = trim ( $value );
	$value = stripslashes ( $value );
	$value = htmlspecialchars ( $value );
	return $value;
}



$SESSION ["fname"] = $_SESSION ["lname"] = $_SESSION ["pnum"] = $_SESSION ["sinNum"] = $_SESSION ["pass"] = $_SESSION ["email"] = "";

if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	include ("db_connection.php");

	 $email = test_input ( $_POST ["email"] );
	 $pass = test_input ( $_POST ["pass"] );
	 $adminCode = test_input($_POST["adminCode"]);
	
	
	$sql = "SELECT * FROM Employee WHERE (EmailAddress = '$email' AND password = '$pass' AND AdminCode = '$adminCode')";
	echo $sql;
	$result = mysqli_query ( $dbConnection, $sql );
	$row = mysqli_fetch_assoc ( $result );
	
	$count = mysqli_num_rows ( $result );
	
	if ($count == 0) { // Account doesn't exist
		$printErr = True;
		
	} else { // Account exists
		
		echo "HERE1";
		print_r($row);
		if(isset($row["AdminCode"]) && $row["AdminCode"] == "999" ){ // password correct
			$_SESSION ["Admin_LoggedIn"] = True;
			echo "HERE2";
			header ( 'Location:SelectAccount.php' );
		} else { // passwrod wrong
			$_SESSION ["Admin_LoggedIn"] = False;
			
			 $printErr = True;
		}
	}

}
?>

<html>

<head>
<title>CreateAccount.php</title>
<link rel="styleSheet" type="text/css" href="styleSheet.css" />
</head>

<body>
<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>

	<div class="content">

		<form method="post">
			<fieldset>
				<legend>Admin Panel:</legend>
				<br /> <br /> 
				
				<label for="email">Email Address </label> 
				<input type="email" name="email" /><br /> <br /> 
				<label for="pass">Password: </label> 
				<input type="password" name="pass" /><br /> <br /> 
				<label for="admin">Admin Code </label> 
				<input type="text" name="adminCode" /><br /> <br /> 
				
				<input type="submit" value="Login" />

			</fieldset>
		</form>

		<?php
		if(isset($printErr)){
				if($printErr == True){
						echo "Wrong Credentials!";
				}
		}

		?>

	</div>

</body>


<?php include "Footer.php"; ?>

</html>



