<!DOCTYPE html>

<?php

session_start ();
function test_input($value) {
	$value = trim ( $value );
	$value = stripslashes ( $value );
	$value = htmlspecialchars ( $value );
	return $value;
}



$SESSION ["fname"] = $_SESSION ["lname"] = $_SESSION ["pnum"] = $_SESSION ["sinNum"] = $_SESSION ["pass"] = $_SESSION ["email"] = "";

if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	include ("db_connection.php");

	$_SESSION ["fname"] = $fname = test_input ( $_POST ["fname"] );
	$_SESSION ["lname"] = $lname = test_input ( $_POST ["lname"] );
	$_SESSION ["pnum"] = $pnum = test_input ( $_POST ["pnum"] );
	$_SESSION ["sinNum"] = $sinNum = test_input ( $_POST ["sinNum"] );
	$_SESSION ["email"] = $email = test_input ( $_POST ["email"] );
	$_SESSION ["pass"] = $pass = test_input ( $_POST ["pass"] );
	$_SESSION["designation"] = $designation= test_input($_POST["designation"]);
	$_SESSION["adminCode"] = $adminCode = test_input($_POST["adminCode"]);
	
	$sql = "INSERT INTO Employee (FirstName, LastName, EmailAddress, TelephoneNumber, SocialInsuranceNumber, Password, Designation, AdminCode) VALUES ('$fname', '$lname', '$email', '$pnum', '$sinNum', '$pass', '$designation', '$adminCode')";
	$result = mysqli_query ( $dbConnection, $sql );
	
	if ($result == FALSE) {
		die ( "Error " . $sql . "<br/>" . mysqli_error ( $dbConnection ) );
	}
	
	
	
	$_SESSION ["valid_login"] = True;
	header ( 'Location: ViewAllEmployees.php' );
	exit ();
}

?>

<html>

<head>
<title>CreateAccount.php</title>
<link rel="styleSheet" type="text/css" href="styleSheet.css" />
</head>

<body>
<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>

	<div class="content">
       <p><font color=red size==2><b><h2>This page should connect to ViewAllEmployees.php when submitting.</br>
	   it works on my local host but not on site ground. Please Consider that ,Thanks</b></h2></font></p>
		<form method="post">
			<fieldset>
				<legend>Create Your New Account:</legend>
				<p>Please fill the form.</p>
				<br /> <br /> 
				<label for="fname">First Name </label>
				<input type="text" name="fname" /><br /> <br />
				
				<label for="lname">Last Name </label> 
				<input type="text" name="lname" /><br /> <br /> 
				
				<label for="email">Email Address </label> 
				<input type="email" name="email" /><br /> <br /> <label for="pnum">Phone Number </label>
				<input type="tel" name="pnum" /><br /> <br /> <label for="sinNum">SIN
				</label>
				<input type="text" name="sinNum" maxlength="11" /><br /> <br />
				<label for="pass">Password: </label> 
				<input type="password" name="pass" /><br /> <br /> 
				<label for="design">Designation </label> 
				<input type="text" name="designation" /><br /> <br /> 
				<label for="admin">Admin Code </label> 
				<input type="text" name="adminCode" /><br /> <br /> 
				
				<input type="submit" value="Submit Information" />

			</fieldset>
		</form>

		

	</div>

</body>

<?php include "Footer.php"; ?>

</html>