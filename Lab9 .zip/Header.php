<?php
echo "<div id=\"header\">";
echo "<h1>Computer Engineering Technology- Web Programming";
echo "</div>";
?>