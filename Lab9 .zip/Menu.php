<?php
echo "<div id=\"menu\">";
echo "<br />";
echo "<br />";
echo '<a href="CreateAccount.php">Create Account</a>';
echo "<br />";
echo "<br />";
echo '<a href="Login.php">Login</a>';
echo "<br />";
echo "<br />";
echo '<a href="ViewAllEmployees.php">View All Employees</a>';
echo "<br />";
echo "<br />";
echo '<a href="SelectAccount.php">Select Account</a>';
echo "<br />";
echo "<br />";
echo "</div>";
?> 