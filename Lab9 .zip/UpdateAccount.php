
<html>

<head>
<title>UpdateAccount.php</title>
<link rel="stylesheet" type="text/css" href="styleSheet.css" />
</head>

<body>

<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>

	<div class="content">
<?php

require "db_connection.php";

?>


							
		Update the following fields.
		<br />
		<br />
		<form action="UpdateComplete.php" method="post">
			<input type="hidden" name="updatepersonId" value="<?php echo  $_POST['personId']; ?>" />
			First Name: <input type="text" name="updatefirstName" value="<?php echo  $_POST['FirstName']; ?>" />
			<br />
			Last Name: <input type="text" name="updatelastName" value="<?php echo  $_POST['LastName']; ?>" />
			<br />
			Email Address: <input type="text" name="updateEmailAddress" value="<?php echo  $_POST['EmailAddress']; ?>" />
			<br />
			TelephoneNumber: <input type= "tel" name="updateTelephoneNumber" value="<?php echo  $_POST['TelephoneNumber']; ?>" />
			<br />
			Designation: <input type= "tel" name="updateDesination" value="<?php echo  $_POST['Designation']; ?>" />
			<br />
			Admin Code: <input type= "text" name="updateadminCode" value="<?php echo  $_POST['AdminCode']; ?>" />
			<br />
			<input type="submit" value="Update Record" />
		</form>
		<br />
		</div>

</body>

<?php include "Footer.php"; ?>

</html>



