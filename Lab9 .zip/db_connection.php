<?php

$host = 'localhost';
$username = 'ujkpdtxkjbava';
$password = 'hassan1360';
$database = 'dbmz6czhsz378c';

$dbConnection = mysqli_connect ( $host, $username, $password, $database );

if (mysqli_connect_errno()) {
	die ( "Connection failed" . mysqli_connect_error () );
	
}else{
	mysqli_select_db($dbConnection, $database);
	
}








?>