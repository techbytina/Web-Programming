  
<!DOCTYPE html>

<?php
session_start ();
function test_input($value) {
	$value = trim ( $value );
	$value = stripslashes ( $value );
	$value = htmlspecialchars ( $value );
	return $value;
}

if ($_SESSION ["Admin_LoggedIn"] == False) {
	header ( 'Location: ./Admin.php' );
}
	include ("db_connection.php");



$sql = "SELECT * FROM Employee;";
$result = mysqli_query ( $dbConnection, $sql );

if ($result == FALSE) {
	die ( "Error " . $sql . "<br/>" . mysqli_error ( $dbConnection ) );
}

?>

<html>

<head>
<title>ViewAllEmployees.php</title>
<link rel="stylesheet" type="text/css" href="styleSheet.css" />
</head>

<body>

<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>

	<div class="content">

	<?php
	
	
	if (mysqli_num_rows ( $result ) > 0) {
		while ( $row = mysqli_fetch_assoc ( $result ) ) {
			
			echo "<button type='button'><a href='UpdateAccount.php?id=". $row["EmployeeId"]  . "'>Edit Employee</a></button>";
			
			echo "First Name: ". $row["FirstName"] ."<br>";
			echo "Last Name: ". $row["LastName"] ."<br><br>";

		}
	}
	
	
	?>
	
</div>

</body>

<?php include "Footer.php"; ?>

</html>