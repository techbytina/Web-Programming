





<head>
<title>ViewAllEmployees.php</title>
<link rel="stylesheet" type="text/css" href="styleSheet.css" />
</head>

<body>

<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>

<div class="content">
<?php

require "db_connection.php";

$error = "";

if(isset($_POST["updateEmployeeId"]))
{
	try {
		$pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
			  // set the PDO error mode to exception
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		echo "Connected successfully" . "</br>";
		
		$sqlQuery = "UPDATE Employee SET FirstName = '".$_POST["updatefirstName"]."', 
										 LastName = '".$_POST["updatelastName"]."',
										 TelephoneNumber = '".$_POST["updateTelephoneNumber"]."',
										 EmailAddress = '".$_POST["updateEmailAddress"]."',
										 Designation = '".$_POST["updateDesination"]."',
										 AdminCode = '".$_POST["updateadminCode"]."'	
					                    WHERE EmployeeId = '".$_POST['updateEmployeeId']."'";
		
		try {
			$result = $pdo->query( $sqlQuery );
			echo "Employee Successfully Updated". "<br>";
			}
		catch(PDOException $e) {
			echo "Employee Could not be Updated:  " . $e->getMessage();
		}	
		
		$pdo = null;		
	}	
	catch(PDOException $e) {
		echo "Connection failed:  " . $e->getMessage();
	}	
	
}

?>
 


</div>

</body>

<?php include "Footer.php"; ?>

</html>
