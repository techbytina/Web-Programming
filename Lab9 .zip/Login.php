<!DOCTYPE html>

<?php
session_start ();
function test_input($value) {
	$value = trim ( $value );
	$value = stripslashes ( $value );
	$value = htmlspecialchars ( $value );
	return $value;
}

$invalid_login = False;
$_SESSION ['valid_login'] = False;

$SESSION ["fname"] = $_SESSION ["lname"] = $_SESSION ["pnum"] = $_SESSION ["sinNum"] = $_SESSION ["pass"] = $_SESSION ["email"] = "";

if ($_SERVER ["REQUEST_METHOD"] == "POST") {
	include ("db_connection.php");

	 $email = test_input ( $_POST ["email"] );
	 $pass = test_input ( $_POST ["pass"] );
	
	
	
	$sql = "SELECT * FROM Employee WHERE (EmailAddress = '$email')";
	$result = mysqli_query ( $dbConnection, $sql );
	$row = mysqli_fetch_assoc ( $result );
	
	$count = mysqli_num_rows ( $result );
	
	if ($count == 0) { // Account doesn't exist
		$valid_login = True;
		echo "This Email is not in my database";
	} else { // Account exists
		$query = "SELECT * FROM EMPLOYEE WHERE Password = '$pass' AND EmailAddress = '$email'";
		$result = mysqli_fetch_assoc( mysqli_query($dbConnection, $query));
		
		if(isset($result["EmailAddress"])){ // password correct
			$_SESSION ["valid_login"] = True;
			$_SESSION ["fname"] = $result["FirstName"];
			$_SESSION ["lname"] =$result["LastName"];
			$_SESSION ["pnum"] = $result["TelephoneNumber"];
			$_SESSION ["sinNum"] = $result["SocialInsuranceNumber"];
			$_SESSION ["email"] = $result["EmailAddress"];
			$_SESSION ["pass"] = $result["Password"];
			$_SESSION["designation"] = $result["Designation"];
			$_SESSION["adminCode"] = $result["AdminCode"];
			$printErr = False;
			header ( 'Location:ViewAllEmployees.php' );
		} else { // passwrod wrong
			$_SESSION ["valid_login"] = False;
			 $printErr = True;
		}
	}
	
	/*
	if ($_SESSION ["valid_login"] == True) {
		header ( 'Location: ./ViewAllEmployees.php' );
	}
	*/
}
?>

<html>

<head>
<title>CreateAccount.php</title>
<link rel="styleSheet" type="text/css" href="styleSheet.css" />
</head>

<body>
<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>

	<div class="content">

		<form method="post">
			<fieldset>
				<legend>Login:</legend>
				<br /> <br /> 
				
				<label for="email">Email Address </label> 
				<input type="email" name="email" /><br /> <br /> 
				<label for="pass">Password: </label> 
				<input type="password" name="pass" /><br /> <br /> 
				
				
				<input type="submit" value="Login" />

			</fieldset>
		</form>

		<?php
		if(isset($printErr)){
				if($printErr == True){
						echo "Email or Password is incorrect.";
				}
		}

		?>

	</div>

</body>


<?php include "Footer.php"; ?>

</html>



