  
<!DOCTYPE html>

<?php
session_start ();
function test_input($value) {
	$value = trim ( $value );
	$value = stripslashes ( $value );
	$value = htmlspecialchars ( $value );
	return $value;
}

if ($_SESSION ["valid_login"] == False) {
	header ( 'Location: ./Login.php' );
}
	include ("db_connection.php");



$sql = "SELECT * FROM Employee;";
$result = mysqli_query ( $dbConnection, $sql );

if ($result == FALSE) {
	die ( "Error " . $sql . "<br/>" . mysqli_error ( $dbConnection ) );
}

?>

<html>

<head>
<title>ViewAllEmployees.php</title>
<link rel="stylesheet" type="text/css" href="styleSheet.css" />
</head>

<body>

<?php include "Header.php"; ?>
<?php include "Menu.php"; ?>

	<div class="content">

	<?php
	
	echo "<h1>Information</h1>";
	
	echo 'First Name: ' . $_SESSION ['fname'];
	echo "<br />";
	echo 'Last Name: ' . $_SESSION ['lname'];
	echo "<br />";
	echo 'Email Address: ' . $_SESSION ['email'];
	echo "<br />";
	echo 'Phone Number: ' . $_SESSION ['pnum'];
	echo "<br />";
	echo 'SIN: ' . $_SESSION ['sinNum'];
	echo "<br />";
	echo 'Password: ' . $_SESSION ['pass'];
	echo "<br />";
	echo 'Designation: ' . $_SESSION ['designation'];
	echo "<br />";
	echo 'Admin Code: ' . $_SESSION ['adminCode'];
	echo "<br />";
	
	
	echo "<br/>";
	echo "<br/>";
	
	echo "<h1>Database Data</h1>";
	echo "<table border='1' width=100%>";
	echo "<tr>";
	echo "<th>First Name</th>";
	echo "<th>Last Name</th>";
	echo "<th>Email Address</th>";
	echo "<th>Phone Number</th>";
	echo "<th>SIN</th>";
	echo "<th>Password</th>";
	echo "<th>Designation</th>";
	echo "<th>Admin Code</th>";
	
	
	echo "</tr>";
	
	if (mysqli_num_rows ( $result ) > 0) {
		while ( $row = mysqli_fetch_assoc ( $result ) ) {
			echo "<tr>";
			echo "<td>" . $row ["FirstName"] . "</td>";
			echo "<td>" . $row ["LastName"] . "</td>";
			echo "<td>" . $row ["EmailAddress"] . "</td>";
			echo "<td>" . $row ["TelephoneNumber"] . "</td>";
			echo "<td>" . $row ["SocialInsuranceNumber"] . "</td>";
			echo "<td>" . $row ["Password"] . "</td>";
			echo "<td>" . $row ["Designation"] . "</td>";
			echo "<td>" . $row ["AdminCode"] . "</td>";
			
			echo "</tr>";
		}
	}
	
	echo "</table>";
	
	?>
	
</div>

</body>

<?php include "Footer.php"; ?>

</html>