<html>

<head>
<title>random.php</title>
<link rel="stylesheet" type="text/css" href="styleSheet.css" />
</head>

<body>

	<?php include "header.php";?>	

	<?php include "menu.php";?>

	<div class="content">
	
		<form method="post" >
		  
			Range 1: <input type="number" name="range1"><br /> 
			Range 2: <input type="number" name="range2"><br /> 
			<input type="submit" value="Order" />		
		</form>	
	
	</div>
	
	<?php include "footer.php";?>

</body>
</html>