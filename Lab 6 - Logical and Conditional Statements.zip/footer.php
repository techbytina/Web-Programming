<?php
	echo "<div id=\"footer\"></br>
	Student Number:040885113 </br> First Name:Maryam </br> last Name:AFshar </br> Email:afsh0004@algonquinlive.com</div>";
?>