



<?php
echo "<div id=\"menu\">";
echo "<br />";
echo "<br />";
echo "<li> <a href= index.php> Index </li> </a>";
echo "<br />";
echo "<br />";
echo "<li> <a href= DivideByThree.php> Divide By Three </li> </a>";
echo "<br />";
echo "<br />";
echo "<li> <a href= random.php> Random </li> </a>";
echo "<br />";
echo "<br />";
echo "<li> <a href= pattern.php> Pattern </li> </a>";
echo "<br />";
echo "<br />";
echo "</div>";
?> 

















