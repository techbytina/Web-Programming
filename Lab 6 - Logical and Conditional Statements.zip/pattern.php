
<html>

<head>
<title>pattern.php</title>
<link rel="stylesheet" type="text/css" href="styleSheet.css" />
</head>

<body>

	<?php include "header.php";?>	

	<?php include "menu.php";?>
	
	<div class="content">
	
	
	
<?php
    echo "<br><br>";
for ($i = 1; $i < 8; $i++) {
    for ($j = $i; $j < 8; $j++){
        echo " &nbsp;&nbsp;";
	}
    for ($j = 2 * $i - 1; $j > 0; $j--){
        echo "*&nbsp;&nbsp;&nbsp; ";
	}
    echo "<br>";
}
$n = 8;
for ($i = 8; $i > 0; $i--) {
    for ($j = $n - $i; $j > 0; $j--){
        echo " &nbsp;&nbsp;";
	}
    for ($j = 2 * $i - 1; $j > 0; $j--){
        echo "*&nbsp;&nbsp;&nbsp; ";
	}
    echo "<br>";
}

?>
	
	
	
	
	
	
	</div>

	<?php include "footer.php";?>

</body>
</html>