<?php
	echo "<div id=\"content\">";
	echo "The include function is adding a header to the top, and footer on the bottom. ";
	echo "Use this technique to develop large applications.<br /><br /><br /><br /><br />";
	echo "</div>";
?>