<?php
	echo "<div id=\"header\"><h1>Welcome to the Include example</h1></div>";
?>