<?php
	echo "<div id=\"footer\"> Student Number:040885113 </br> Email:afsh0004@algonquinlive.com</div>";
?>