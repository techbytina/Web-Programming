<?php

$first="Maryam";
$last="Afshar";
define("Student Number","040885113");

$hello = "Hello World";
$hey =" This is the first time I am using PHP!!";


echo "<div id=\"menu\">";

echo "<ul>";



echo "<li> <a href= \"http://maryama1.sgedu.site/lab2/index.html \"> Lab2 </li> </a>";
echo "<li> <a href= \"http://maryama1.sgedu.site/lab3/index.html \"> Lab3 </li> </a>";
echo "<li> <a href= \"http://maryama1.sgedu.site/lab4/index.html \"> Lab4 </li> </a>";


echo "</ul>";
echo "</div>";

echo "<div id=\"content\">";



echo "</div>";



?>

